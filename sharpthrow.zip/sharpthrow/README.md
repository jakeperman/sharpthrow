# sharpthrow

throwing knife game

central mechanic is the throwing knife

throwing knife is used to :
- attack
- complete puzzles
- accelerate movement
- and more
- create footholds in wall (pegs)


cool down on throwing knives, can only throw so many at a time

kinds of weapons:
- standard knife
- axe
- tomahawk
- battle axe
- double sided knife
- butterfly knife
- scythe 
- more
- boomerang 
